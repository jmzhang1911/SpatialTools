#!/share/nas2/genome/biosoft/Python//3.7.3/bin/python3
# -*- coding: utf-8 -*-
# @Time : 2022/12/5 22:07
# @Author : jmzhang
# @Email : zhangjm@biomarker.com.cn

class SpatialAppDemo:

    meta_data = None
    spatial_tools_object = None
    adata = None
    feature = None
    color_by = None

    @classmethod
    def run_dash(cls):
        pass

    pass