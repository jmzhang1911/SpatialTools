__version__ = '2.1.9'

from spatial_tools.spatial_tools import SpatialApp, SpatialTools
